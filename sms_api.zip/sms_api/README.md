# README #

This is Repo for WhatsAPP SMS API using Django code.

### What is this repository for? ###

* Quick summary
* Version: 1.0

### Dev DB Credentials Local ###

* DB Name: admin
* Username: venpep
* Password: venpep123


### Steps for Setting Up the Project ###

#### Step 1:  Create Virtual Environment ####

* python3 -m venv sms_api_env

#### Step 2:  Activate Virtual Enviroment ####

source sms_api_env/bin/activate 

#### Step 3:  Install Django using PIP ####

* pip3 install django 

To start Start New Project
* django-admin startproject < project name > // crm

#### Step 4:  Set Up Database ####

* python3 manage.py makemigrations 
* python3 manage.py migrate 
* python3 manage.py collectstatic

#### Step 4:  Run Server ####

* Run Server - python3 manage.py runserver

#### Step 5:  Create App ####

* python3 manage.py startapp < app name > // admin_dashboard

#### Install Following libraries ####

* pip install django twilio pyngrok
* pip install pymongo
