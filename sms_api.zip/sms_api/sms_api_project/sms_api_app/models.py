from django.db import models

# Create your models here.
class SMS(models.Model):
    sms_id = models.AutoField(primary_key=True)
    sms_from_name = models.CharField(max_length=100, blank=True, null=True)
    sms_from = models.CharField(max_length=100, blank=True, null=True)
    sms_to = models.CharField(max_length=100, blank=True, null=True)
    message = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    class Meta:
        db_table = 'sms_notifications'