from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from twilio.twiml.messaging_response import MessagingResponse
from sms_api_app.models import SMS
# Create your views here.

@csrf_exempt
def message(request):
    user = request.POST.get('From')
    message = request.POST.get('Body')
    profilename = request.POST.get('ProfileName')
    to = request.POST.get('To')
    sms_notify = SMS.objects.create(sms_from_name=profilename, sms_from=user, sms_to=to, message=message)
    sms_notify.save()
    response = MessagingResponse()
    response.message('Thank for your message!')
    return HttpResponse(str(response))