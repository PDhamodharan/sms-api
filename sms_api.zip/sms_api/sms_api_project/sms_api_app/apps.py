from django.apps import AppConfig


class SmsApiAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sms_api_app'
